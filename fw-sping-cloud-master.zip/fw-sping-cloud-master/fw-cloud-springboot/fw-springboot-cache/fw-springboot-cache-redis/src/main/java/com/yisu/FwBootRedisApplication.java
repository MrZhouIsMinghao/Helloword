package com.yisu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 *
 * @Author xuyisu
 * @Date 2020/01/18
 */
@SpringBootApplication
public class FwBootRedisApplication {
    public static void main(String[] args) {
        SpringApplication.run(FwBootRedisApplication.class, args);
    }
}