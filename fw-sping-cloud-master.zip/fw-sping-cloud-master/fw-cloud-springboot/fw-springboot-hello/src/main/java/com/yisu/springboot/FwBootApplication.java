package com.yisu.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 *
 * @Author xuyisu
 * @Date 2019/12/6
 */
@SpringBootApplication
public class FwBootApplication {
    public static void main(String[] args) {
        SpringApplication.run(FwBootApplication.class, args);
    }
}