package com.yisu.profile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 *
 * @Author xuyisu
 * @Date 2020/01/12
 */
@SpringBootApplication
public class FwProfileApplication {
    public static void main(String[] args) {
        SpringApplication.run(FwProfileApplication.class, args);
    }
}