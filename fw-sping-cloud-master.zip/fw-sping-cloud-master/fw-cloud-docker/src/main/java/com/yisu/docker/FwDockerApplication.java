package com.yisu.docker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 *
 * @Author xuyisu
 * @Date 2020/03/14
 */
@SpringBootApplication
public class FwDockerApplication {
    public static void main(String[] args) {
        SpringApplication.run(FwDockerApplication.class, args);
    }
}